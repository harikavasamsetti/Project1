This repository holds the task that was assigned to me during the course of Infosys Springboard internship.
